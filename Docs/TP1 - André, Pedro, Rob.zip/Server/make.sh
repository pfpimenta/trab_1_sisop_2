g++ server.cpp -o server -pthread
