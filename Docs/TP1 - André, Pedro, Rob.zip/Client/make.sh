g++ client.cpp -o client -pthread
